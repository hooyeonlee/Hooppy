package com.social.google;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocialGoogleApplicationTests {

	@Test
	void contextLoads() {
	}

}
