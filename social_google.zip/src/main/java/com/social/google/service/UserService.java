package com.social.google.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.social.google.Role;
import com.social.google.dto.UserDto;
import com.social.google.entity.UserEntity;
import com.social.google.repository.UserRepository;
import com.social.google.security.SessionUser;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class UserService implements UserDetailsService{
	
	@Autowired
	UserRepository userRepository;
	
	public UserEntity createUser(UserDto userDto) {
		
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		userDto.setPwd(encoder.encode(userDto.getPwd()));
		
		/*
		 * userDto = userRepository.findBySocialEmail(userDto.getEmail()) .map(entity ->
		 * entity.update(userDto.getName(), attributes.getSocialPicture()))
		 * .orElse(userDto.toEntity());
		 */
		 
		return userRepository.save(UserEntity.builder()
											 .userId(userDto.getUserId())
											 .name(userDto.getName())
											 .gender(userDto.getGender())
											 .phone(userDto.getPhone())
											 .ci(userDto.getCi())
											 .pwd(userDto.getPwd())
											 .socialToken(userDto.getSocialToken())
											 .type(userDto.getType())
											 .build());
	}
	
	public int isExistMember(SessionUser sessionUser) {
		return userRepository.countBySocialToken(sessionUser.getSocialToken());
	}

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<UserEntity> userEntityOptional = userRepository.findByUserId(username);
        UserEntity userEntity = userEntityOptional.orElse(null);

        List<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority(Role.MEMBER.getKey()));

        return new UserDto(userEntity.getUserId(),
        				   userEntity.getName(),
        				   userEntity.getGender(),
        				   userEntity.getPhone(),
        				   userEntity.getCi(),
        				   userEntity.getPwd(),
        				   userEntity.getSocialToken(),
        				   userEntity.getType());
	}
	
}
