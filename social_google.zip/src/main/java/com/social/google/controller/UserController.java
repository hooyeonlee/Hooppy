package com.social.google.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.social.google.dto.UserDto;
import com.social.google.security.SessionUser;
import com.social.google.service.UserService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Controller
public class UserController {
	
	private final HttpSession httpSession;
	
	@Autowired
	UserService userService;
	
	@GetMapping("/")
	public String index() {
		return "index";
	}
	
	@GetMapping("/decide")
	public String decide(Model model) {
		SessionUser sessionUser = (SessionUser) httpSession.getAttribute("user");
		
		model.addAttribute("user", sessionUser);
		
		int cnt = userService.isExistMember(sessionUser);
		
		if(cnt > 0) {
			return "index";
		}else {
			return "join_page";
		}
	}
	
	@PostMapping("/join")
	public String join(UserDto userDto) {
		
		log.info("userDto : " + userDto.getPwd());
		
		userService.createUser(userDto);
		
		return "join_complete";
	}
	
	@GetMapping("/login_page")
	public String loginPage() {
		return "login_page";
	}
	
	@GetMapping("/signup_page")
	public String signupPage() {
		return "signup_page";
	}
	
	@PostMapping("/signup")
	public String signup(UserDto userDto) {
		userService.createUser(userDto);
		return "login_page";
	}
}
