package com.social.google.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.social.google.entity.UserEntity;

public interface UserRepository extends JpaRepository<UserEntity, Long>{
	Optional<UserEntity> findByUserId(String username);
	int countBySocialToken(String socialToken);
}
