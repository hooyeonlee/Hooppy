package com.example.demo.util;

import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;

public class KakaoUtil {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass().getSimpleName());
	
	public ResponseEntity<Map> createTokenApi(String code, String uri){
		
		RestTemplate restTemplate = new RestTemplate();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(new MediaType("application", "x-www-form-urlencoded", StandardCharsets.UTF_8));
				
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		
		try {
			
			params.add("grant_type","authorization_code"); 
			params.add("client_id","6e381405faa01ef62b40f38e81a8a38b");
			params.add("redirect_uri","http://localhost:8080/kakao/index"); 
			params.add("code", code);
			params.add("client_secret", "JUFiFCFylnMfpoAbr2kxzw5WQVWsN2l9");
		   
			HttpEntity<MultiValueMap<String, String>> requestBody = new HttpEntity<MultiValueMap<String, String>>(params, headers);
			
			logger.info("1 : " + requestBody);
			
			ResponseEntity<Map> response = restTemplate.exchange(uri, HttpMethod.POST, requestBody, Map.class);
			
			return response;
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		 
		return null;
	}
	
	public ResponseEntity<Map> takeUserIdApi(String access_token, String uri){
		
		RestTemplate restTemplate = new RestTemplate();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(new MediaType("application", "x-www-form-urlencoded", StandardCharsets.UTF_8));
		headers.setBearerAuth(access_token);
				
		try {
			
			HttpEntity<String> requestHeader = new HttpEntity<String>(headers);
			
			logger.info("2 : " + requestHeader);
			
			ResponseEntity<Map> response = restTemplate.exchange(uri, HttpMethod.GET, requestHeader, Map.class);
			
			logger.info("3 : " + response);
			
			return response;
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		 
		return null;
	}
	
	public ResponseEntity<Map> takeUserInfoApi(String target_id, String uri){
		
		RestTemplate restTemplate = new RestTemplate();
		
		Gson gson = new Gson();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(new MediaType("application", "x-www-form-urlencoded", StandardCharsets.UTF_8));
		headers.set("Authorization", "KakaoAK c6bc9e2e336c8e5e50535aa8079f876b");
		
		MultiValueMap<String, String> params = new LinkedMultiValueMap<String, String>();
		
		try {
			
			params.add("target_id_type", "user_id");
			params.add("target_id", target_id);
			params.add("property_keys", "[\"kakao_account.nickname\"]");
			
			logger.info("params : " + params);
			
			HttpEntity<MultiValueMap<String, String>> requestBody = new HttpEntity<MultiValueMap<String, String>>(params, headers);
			
			logger.info("4 : " + requestBody);
			
			ResponseEntity<Map> response = restTemplate.postForEntity(uri, requestBody, Map.class);
			
			logger.info("5 : " + gson.toJson(response.getBody(), Map.class));
			
			return response;
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		 
		return null;
	}
	
	public ResponseEntity<Map> postUnlinkApi(String access_token, String uri){
		
		RestTemplate restTemplate = new RestTemplate();
		
		HttpHeaders headers = new HttpHeaders();
		headers.setBearerAuth(access_token);
				
		try {
			
			HttpEntity<String> requestHeader = new HttpEntity<String>(headers);
			
			ResponseEntity<Map> response = restTemplate.exchange(uri, HttpMethod.POST, requestHeader, Map.class);
			
			logger.info("1 : " + response.getBody());
			
			return response;
			
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		 
		return null;
	}
}
