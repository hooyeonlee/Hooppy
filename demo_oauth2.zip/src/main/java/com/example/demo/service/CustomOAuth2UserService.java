package com.example.demo.service;

import java.util.Collections;

import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserService;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.DefaultOAuth2User;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import com.example.demo.dao.IntegrationRepository;
import com.example.demo.dto.IntegrationDto;
import com.example.demo.dto.IntegrationEntity;
import com.example.demo.dto.OAuthAttributes;

import lombok.AllArgsConstructor;

@Service
@AllArgsConstructor
public class CustomOAuth2UserService implements OAuth2UserService<OAuth2UserRequest, OAuth2User> {

    private IntegrationRepository integrationRepository;

    public IntegrationEntity joinUser(IntegrationDto integrationDto) {
        // 비밀번호 암호화
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        integrationDto.setUpwd(passwordEncoder.encode(integrationDto.getUpwd()));

        return integrationRepository.save(integrationDto.toEntity());
    }

	@Override
	public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
		
		OAuth2UserService delegate = new DefaultOAuth2UserService();
		OAuth2User oAuth2User = delegate.loadUser(userRequest);
		
		String registerationId = userRequest.getClientRegistration().getRegistrationId();
		
		String userNameAttributeName = userRequest.getClientRegistration().getProviderDetails().getUserInfoEndpoint().getUserNameAttributeName();
		
		OAuthAttributes attributes = OAuthAttributes.of(registerationId, userNameAttributeName, oAuth2User.getAttributes());
		
		IntegrationEntity kakaointegrationEntity = saveOrUpdate(attributes);
		
		return new DefaultOAuth2User(Collections.singleton(new SimpleGrantedAuthority(kakaointegrationEntity.getRoleKey()))	
									    ,attributes.getAttributes()
									    ,attributes.getNameAttributeKey());					
		
	}
	
	private IntegrationEntity saveOrUpdate(OAuthAttributes attributes) {
		IntegrationEntity kakaoEntity = integrationRepository.findByName(attributes.getName())
				.map(entity->entity.update(attributes.getName(), attributes.getEmail()))
				.orElse(attributes.toEntity());
		
		return integrationRepository.save(kakaoEntity);
	}
}