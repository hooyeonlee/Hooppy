package com.example.demo.controller;

import java.util.Map;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AccessToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.dao.UserDAO;
import com.example.demo.dto.IntegrationDto;
import com.example.demo.service.CustomOAuth2UserService;
import com.example.demo.service.MemberService;
import com.example.demo.util.KakaoUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.AllArgsConstructor;

@Controller
@AllArgsConstructor
@MapperScan("com.example.demo.dao")
public class DemoController {
	
	UserDAO userDAO;
	
	MemberService memberService;
	
	ObjectMapper objectMapper;
	
	@GetMapping("/kakao/index")
	public String index(Model model, @RequestParam String code) {
		
		KakaoUtil kakaoUtil = new KakaoUtil();
		
		ResponseEntity<Map> createTokenMap;
		ResponseEntity<Map> takeUserId;
		ResponseEntity<Map> takeUserInfo;
		
		createTokenMap = kakaoUtil.createTokenApi(code, "https://kauth.kakao.com/oauth/token");
		
		String access_token = (String) createTokenMap.getBody().get("access_token");
		
		takeUserId = kakaoUtil.takeUserIdApi(access_token, "https://kapi.kakao.com/v2/user/me");
		
		//int target_id = (int) takeUserId.getBody().get("id");
		
		//takeUserInfo = kakaoUtil.takeUserInfoApi(String.valueOf(target_id), "https://kapi.kakao.com/v2/user/me");
		
		model.addAttribute("result", takeUserId.getBody());
		
		return "index";
	}
	
	@PostMapping("logout")
	public String logout() {
		
		return "/user/login_page";
	}
	
	@RequestMapping(value = "/kakao/unlink", method = {RequestMethod.GET, RequestMethod.POST})
	public String unlink() {
		
		KakaoUtil kakaoUtil = new KakaoUtil();
		
		ResponseEntity<Map> postUnlinkMap;
		
		postUnlinkMap = kakaoUtil.postUnlinkApi("L60rItq4su6kH2nph8eGkV7na6hlboPySF_qNwopcFEAAAF4eAbqGg", "https://kapi.kakao.com/v1/user/unlink");
		
		return "/user/login_page";
	}
	
	//회원가입 처리
    @PostMapping("/user/signUp")
    public String execSignup(IntegrationDto memberDto) {

        memberService.joinUser(memberDto);
        return "redirect:/user/login_page";
    }
    
    //로그인 페이지
    @GetMapping("/user/login_page")
    public String login_page() {
        return "/user/login_page";
    }

    //회원가입 페이지
    @GetMapping("/user/sign_up")
    public String sign_up_page() {
        return "/user/sign_up_page";
    }    
}
